import React, { Component } from "react";
import BottomTabNavigator from "./components/BottomTabNavigator";

export default class App extends Component {
  render() {

    //return <BottomTabNavigator>;
    //<BottomTabNavigator />;
    //return <BottomTabNavigator />;
    //return <BottomTabNavigator> <BottomTabNavigator />;
    
  }
}
